package com.example.nguyenducnhat.nhatstore.Model;

public class Orders {
    public int id;

    public Orders(int id) {
        this.id = id;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
}
